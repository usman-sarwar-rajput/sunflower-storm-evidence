from pathlib import Path
import csv, json, hashlib
import openpyxl
p=Path(__file__).resolve().parent
rows=list(csv.DictReader((p/'data/observations_192.csv').open()))
assert len(rows)==192
assert len({r['plot'] for r in rows})==48
assert len({(r['plot'],r['date']) for r in rows})==192
assert {r['date'] for r in rows}=={'2016-08-15','2016-08-18','2016-08-23','2016-08-31'}
w=openpyxl.load_workbook(p/'CanopyCover_original.xlsx',data_only=True)['Canopy Cover']
for r in rows:
    assert abs(float(r['cover_fraction'])*100-float(r['cover_percent']))<1e-9
    assert 0<=float(r['cover_percent'])<=100
    assert w.cell(int(r['source_row']),4).value==r['plot']
    assert abs(w.cell(int(r['source_row']),7).value*100-float(r['cover_percent']))<1e-9
stages=list(csv.DictReader((p/'data/five_stages_with_plot_ids.csv').open()))
assert len(stages)==48
assert all(r['during_storm_2016_08_19_pct']=='' and r['during_storm_status']=='not_measured' for r in stages)
for name,digest in json.loads((p/'checksums_sha256.json').read_text()).items():
    assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
print('PASS: 192 source-matched observations, 48 plots, four measured dates, no imputed storm values, all release hashes.')
