# Data rights and attribution

The underlying USDA-ARS Colorado dataset is designated **U.S. Public Domain** in the pinned source metadata: https://doi.org/10.15482/USDA.ADC/28586066.v2 . Original authors and license metadata are preserved in source_metadata.json. Derived factual tables retain source attribution. No new blanket license or ownership claim is applied to third-party material. This notice applies to the Colorado canopy release only; the repository's independent Brooks stem-angle and DeValk inclination sources have their own terms described in the root README.
