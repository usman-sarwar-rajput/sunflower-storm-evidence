# Sunflower canopy cover around the 19 August 2016 hailstorm

A documented secondary analysis of USDA field measurements at Greeley, Colorado. **This measures green canopy cover, not head or stem movement. It does not establish storm prediction.**

## Download and start

Use [observations_192.csv](data/observations_192.csv) for analysis (one row per plot/date), or [five_stages_with_plot_ids.csv](data/five_stages_with_plot_ids.csv) for an accessible comparison retaining plot identifiers. [Excel workbook](data/Sunflower_Five_Stages.xlsx) is also provided.

## Coverage

| Stage | Observation date | Plots measured | Mean green cover (%) |
|---|---|---:|---:|
| Early | 2016-08-15 | 48 | 84.05 |
| Pre-storm | 2016-08-18 | 48 | 82.53 |
| During storm | 2016-08-19 | 0 | Not measured |
| First after | 2016-08-23 | 48 | 50.09 |
| Later after | 2016-08-31 | 48 | 38.22 |

There are 192 selected observations, 48 plots and four experimental blocks. Dates are field observation dates, not exact timestamps. The crop log records hail on 19 August; exact local onset is unknown. A date match does not resolve within-day exposure.

## Files

- `data/observations_192.csv`: measured long-format subset.
- `data/plot_values.csv`: measured wide-format subset with identifiers.
- `data/five_stages_with_plot_ids.csv`: five-stage presentation; storm-day numeric cells are empty and status is `not_measured`.
- `data/Sunflower_Five_Stages.csv` and `.xlsx`: presentation tables; consult the workbook explanation for plot mapping.
- `data/canopy_plot_observations.csv`: full cleaned 2008–2016 canopy series.
- `data/station_daily_weather.csv`: full cleaned daily weather series; `weather_context.csv` is the figure subset.
- `results/`: derived summaries, paired contrasts, block and treatment summaries, and seasonal context.
- `SOURCE_DATA_DICTIONARY.csv`: unchanged published dictionary for original fields, units and treatment definitions.
- `source_metadata.json` and `source_manifest.json`: pinned source metadata, original download links and checked MD5 values. Paths in the manifest refer to the local raw-data package; originals can be downloaded using its URLs.
- `checksums_sha256.json`: integrity hashes for this folder's deliverables.

## Measurements and processing

The source study estimated green canopy fraction from periodic overhead photographs, classifying green pixels relative to total image area. This is an image-derived cover estimate, not a direct measurement of biomass, mortality or plant motion. The cleaned table retains plot, treatment, block, date and source row. Cover percent equals cover fraction multiplied by 100. The selected subset retains four actual observation dates; it does not interpolate storm-day readings.

The existing repository [analysis code](../../code/analyse.py) rebuilds the full cleaned source tables from the original inputs. This release adds a four-date selection and five-stage presentation. Run `python datasets/canopy_hailstorm_2016/validate.py` from the repository root to check row counts, keys, values, source-workbook measurements and release hashes. The validator is not a statistical-analysis pipeline.

## Field dictionary

| Field | Meaning |
|---|---|
| `plot` | Original plot identifier; retain for repeated-measures comparisons |
| `treatment` | Source treatment code; consult original methodology |
| `block` | Experimental block identifier |
| `date` | Observation date, YYYY-MM-DD |
| `cover_fraction` | Green canopy fraction, from 0 to 1 |
| `cover_percent` | Green canopy percentage, from 0 to 100 |
| `source_row` | Original workbook row number, including headers |

The five-stage table's `_pct` columns use percent; date and stage are embedded in their names. `during_storm_status` explains the blank numeric storm column. Blank is missing, not zero. Legacy presentation files use the text `Not measured` for the same absence. For weather units and original missing-value conventions consult the source dictionary; no assumptions about missing values should be made from zero alone.

## Interpretation and limitations

Mean cover fell by 32.44 percentage points between 18 and 23 August, and all 48 plots declined. This interval spans a documented hailstorm. No published storm-day canopy readings are available, and the source does not explain their absence. No measurements were invented. Four blocks do not constitute four independent storms. The reported block-level tests are conditional on their model assumptions; they cannot establish a causal storm effect. Growth stage, earlier hail, irrigation treatments, uneven emergence and seasonal changes limit interpretation. Neither the small pre-storm decline nor subsequent loss demonstrates a warning signal. Later cover did not return to the earlier level during these visits.

## Source, attribution and reuse

Original measurements: [USDA-ARS Colorado Sunflower Water Use and Productivity Dataset, version 2](https://doi.org/10.15482/USDA.ADC/28586066.v2). Source author details are preserved in `source_metadata.json`. Cite the original source and identify this repository as the secondary cleaning/analysis source. USDA labels the source U.S. Public Domain. This release adds selection, formatting, derived results and documentation; it does not claim ownership of the original measurements. See [LICENSE.md](LICENSE.md). No new DOI has been assigned to this derivative dataset; for reproducibility cite the Git commit used.
